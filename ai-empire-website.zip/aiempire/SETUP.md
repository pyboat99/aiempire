# THE AI EMPIRE — Website Setup Guide

## One-Time Setup (15 minutes)

### Step 1: Create a GitHub account
Go to github.com and sign up free. Choose any username.

### Step 2: Create a new repository
- Click the green "New" button on your GitHub dashboard
- Name it: `ai-empire`
- Set it to **Public**
- Click "Create repository"

### Step 3: Upload the files
- Click "uploading an existing file" on the empty repo page
- Drag and drop ALL files from this folder into the upload area
- Scroll down and click "Commit changes"

### Step 4: Enable GitHub Pages
- Go to your repo → Settings → Pages (left sidebar)
- Under "Source", select **GitHub Actions**
- Save

### Step 5: Your site is live
Within 2-3 minutes, your site will be live at:
`https://YOUR-USERNAME.github.io/ai-empire`

---

## Adding a New Chapter (Every time a chapter is built)

When a new chapter is built in the Claude chat session:

1. Copy the full HTML of the chapter widget
2. Save it as `ch11.html` (or whatever the chapter number is)
3. Upload it to your GitHub repo (drag and drop → commit)
4. In `index.html`, find the chapter entry and change `live:false` to `live:true` and add `src:'ch11.html'`
5. Push the change

**The site updates automatically within 60 seconds of pushing.**

---

## File Structure
```
ai-empire/
├── index.html          ← Main site (navigation, hero, shell)
├── ch01.html           ← Chapter 1 (replace placeholder with real content)
├── ch02.html           ← Chapter 2
├── ...
├── ch10.html           ← Chapter 10
├── README.md
├── SETUP.md            ← This file
└── .github/
    └── workflows/
        └── deploy.yml  ← Auto-deploy to GitHub Pages
```

## Custom Domain (Optional)
Once live, you can connect a custom domain (e.g. theaiempire.com) in:
Settings → Pages → Custom domain
Domain registration: Namecheap.com (~$10/year for .com)
